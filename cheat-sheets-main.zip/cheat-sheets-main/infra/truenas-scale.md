# TrueNAS Scale
WIP

---
## ACME
WIP

1. Create DNS Credentials
2. Create Signing Request
3. Configure email address for your current user (in case of root, info)
4. Create ACME Cert
5. Switch Admin Cert

---
