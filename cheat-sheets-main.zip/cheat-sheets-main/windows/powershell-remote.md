# PowerShell Remote Access


---
## Open new Remote Session

```powershell
Enter-PSSession -ComputerName <SERVER> -Credential <USERNAME>
```
