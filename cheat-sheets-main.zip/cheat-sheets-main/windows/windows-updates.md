# Windows Updates


---
## PowerShell
### Install Windows Update
```powershell
Install-Module -Name PSWindowsUpdate
```
### List all Commands
```powershell
Get-Command -module PSWindowsUpdate
```

```powershell
Get-WUInstall
```

