# VSCode (Visual Studio Code)

**VSCode Shortcuts on MacOS ([[vscode-macos-shortcuts]])**