# User Management

COMMAND | DESCRIPTION
---|---
`sudo adduser username` | Create a new user
`sudo userdel username` | Delete a user
`sudo usermod -aG groupname username` | Add a user to group
`sudo deluser username groupname` | Remove a user from a group