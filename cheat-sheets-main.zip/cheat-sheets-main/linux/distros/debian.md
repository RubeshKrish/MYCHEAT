# Debian

Debian also known as Debian GNU/Linux, is a [Linux](../linux.md) distribution composed of free and open-source software, developed by the community-supported Debian Project. The Debian Stable branch is the most popular edition for personal computers and servers. Debian is also the basis for many other distributions, most notably [Ubuntu](ubuntu.md).
