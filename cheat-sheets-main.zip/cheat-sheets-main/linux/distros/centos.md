# CentOS

CentOS, from Community Enterprise Operating System; also known as CentOS Linux) is a Linux distribution that provides a free and open-source community-supported computing platform, functionally compatible with its upstream source, Red Hat Enterprise Linux (RHEL). CentOS announced the official joining with Red Hat while staying independent from RHEL, under a new CentOS governing board.

