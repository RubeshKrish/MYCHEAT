# SED Cheat-Sheet
**sed** ("stream editor") is a **Linux ([[linux]])**, and Unix utility that parses and transforms text, using a simple, compact programming language.

TMP
replace pattern: 
```
sed -i 's/Steven/Kate/' file
```