# Tailscale
Tailscale is a zero config [VPN](networking/vpn.md) for building secure networks, powered by [wireguard](networking/wireguard.md). Install on any device in minutes. Remote access from any network or physical location.

Project Homepage: https://tailscale.com

---
