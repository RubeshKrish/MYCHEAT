# Portainer
Easily deploy, configure and secure containers in minutes on [Docker](docker/docker.md), [Kubernetes](kubernetes/kubernetes.md), Swarm and Nomad in any cloud, datacenter or device.

Project Homepage: [Portainer](https://www.portainer.io)
Documentation: [Portainer Docs](http://documentation.portainer.io)

---
