# Google Chrome

## Advanced

### No "Proceed Anyway" Option

Chrome on MacOS won't show a "Proceed Anyway" Option on `NE:ERR_CERT_INVALID` invalid SSL Certificates. Use the secret passphrase as a workaround.

1. Make sure the website is selected
2. Just type in `thisisunsafe`