# Docker on macOS Silicon
## Installation
Docker Desktop

## Platform
```
docker run --platform linux/arm/v7

docker run --platform linux/amd64
```

## Shared volumes
Shared volumes can be configured in the Docker Desktop Settings `Docker -> Preferences... -> Resources -> File Sharing`

